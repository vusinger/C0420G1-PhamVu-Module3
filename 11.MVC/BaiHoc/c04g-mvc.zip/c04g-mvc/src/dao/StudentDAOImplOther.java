package dao;

import model.Student;

import java.util.List;

public class StudentDAOImplOther implements StudentDAO {
    @Override
    public List<Student> findAll() {
        return null;
    }
}
